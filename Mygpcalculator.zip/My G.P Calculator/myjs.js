<script>
function mygp() {

var gns101sc=document.getElementById("gns101score").value;
var gns127sc=document.getElementById("gns127score").value;
var gns121sc=document.getElementById("gns121score").value;
var math112sc=document.getElementById("math112score").value;
var stat111sc=document.getElementById("stat111score").value;
var gns101cu=2;
var gns127cu=2;
var gns121cu=2;
var math112cu=2;
var stat111cu=2;

var gns101gp="";

if(gns101sc >= 75) 
{
gns101gp=4.00; gns101g="A"; }
else if(gns101sc >= 70) {
gns101gp=3.50; gns101g="AB";}
else if(gns101sc >=65)
{gns101gp=3.00; gns101g="B";}
else if(gns101sc >=60)
{gns101gp=3.50; gns101g="BC";}
else if(gns101sc >=55)
{gns101gp=2.27; gns101g="C"} 
else if(gns101sc >=50)
{gns101gp=2.50; gns101g="CD";
} else if( gns101sc >=45) 
{gns101gp=2.25; gns101g="D";}
else if( gns101sc >=40) 
{gns101gp=2.00; gns101g="P";}
else if( gns101sc >=30) 
{gns101gp=1.50; gns101g="F3";}
else if( gns101sc >=20) 
{gns101gp=1.00; gns101g="F2";} 
else if( gns101sc >=10) 
{gns101gp=0.50; gns101g="F1";}
else if( gns101sc >=0) 
{gns101gp=0.00; gns101g="F";}
var gns127gp="";

if(gns127sc >= 75) 
{
gns127gp=4.00; gns127g="A"; }
else if(gns127sc >= 70) {
gns127gp=3.50; gns127g="AB";}
else if(gns127sc >=65)
{gns127gp=3.00; gns127g="B";}
else if(gns127sc >=60)
{gns127gp=3.50; gns127g="BC";}
else if(gns127sc >=55)
{gns127gp=2.27; gns127g="C"} 
else if(gns127sc >=50)
{gns127gp=2.50; gns127g="CD";
} else if( gns127sc >=45) 
{gns127gp=2.25; gns127g="D";}
else if( gns127sc >=40) 
{gns127gp=2.00; gns127g="P";}
else if( gns127sc >=30) 
{gns127gp=1.50; gns127g="F3";}
else if( gns127sc >=20) 
{gns127gp=1.00; gns127g="F2";} 
else if( gns127sc >=10) 
{gns127gp=0.50; gns127g="F1";}
else if( gns127sc >=0) 
{gns127gp=0.00; gns127g="F";}
var gns121gp="";

if(gns121sc >= 75) 
{
gns121gp=4.00; gns121g="A"; }
else if(gns121sc >= 70) {
gns121gp=3.50; gns121g="AB";}
else if(gns121sc >=65)
{gns121gp=3.00; gns121g="B";}
else if(gns121sc >=60)
{gns121gp=3.50; gns121g="BC";}
else if(gns121sc >=55)
{gns121gp=2.27; gns121g="C"} 
else if(gns121sc >=50)
{gns121gp=2.50; gns121g="CD";
} else if( gns121sc >=45) 
{gns121gp=2.25; gns121g="D";}
else if( gns121sc >=40) 
{gns121gp=2.00; gns121g="P";}
else if( gns121sc >=30) 
{gns121gp=1.50; gns121g="F3";}
else if( gns121sc >=20) 
{gns121gp=1.00; gns121g="F2";} 
else if( gns121sc >=10) 
{gns121gp=0.50; gns121g="F1";}
else if( gns121sc >=0) 
{gns121gp=0.00; gns121g="F";}
var math112gp="";

if(math112sc >= 75) 
{
math112gp=4.00; math112g="A"; }
else if(math112sc >= 70) {
math112gp=3.50; math112g="AB";}
else if(math112sc >=65)
{math112gp=3.00; math112g="B";}
else if(math112sc >=60)
{math112gp=3.50; math112g="BC";}
else if(math112sc >=55)
{math112gp=2.27; math112g="C"} 
else if(math112sc >=50)
{math112gp=2.50; math112g="CD";
} else if( math112sc >=45) 
{math112gp=2.25; math112g="D";}
else if( math112sc >=40) 
{math112gp=2.00; math112g="P";}
else if( math112sc >=30) 
{math112gp=1.50; math112g="F3";}
else if( math112sc >=20) 
{math112gp=1.00; math112g="F2";} 
else if( math112sc >=10) 
{math112gp=0.50; math112g="F1";}
else if( math112sc >=0) 
{math112gp=0.00; math112g="F";}
var stat111gp="";

if(stat112sc >= 75) 
{
stat112gp=4.00; stat112g="A"; }
else if(stat112sc >= 70) {
stat112gp=3.50; stat112g="AB";}
else if(stat112sc >=65)
{stat112gp=3.00; stat112g="B";}
else if(stat112sc >=60)
{stat112gp=3.50; stat112g="BC";}
else if(stat112sc >=55)
{stat112gp=2.27; stat112g="C"} 
else if(stat112sc >=50)
{stat112gp=2.50; stat112g="CD";
} else if( stat112sc >=45) 
{stat112gp=2.25; stat112g="D";}
else if( stat112sc >=40) 
{stat112gp=2.00; stat112g="P";}
else if( stat112sc >=30) 
{stat112gp=1.50; stat112g="F3";}
else if( stat112sc >=20) 
{stat112gp=1.00; stat112g="F2";} 
else if( stat112sc >=10) 
{stat112gp=0.50; stat112g="F1";}
else if( stat112sc >=0) 
{stat112gp=0.00; stat112g="F";}
var mec101gp="";

if(mec101sc >= 75) 
{
mec101gp=4.00; mec101g="A"; }
else if(mec101sc >= 70) {
mec101gp=3.50; mec101g="AB";}
else if(mec101sc >=65)
{mec101gp=3.00; mec101g="B";}
else if(mec101sc >=60)
{mec101gp=3.50; mec101g="BC";}
else if(mec101sc >=55)
{mec101gp=2.27; mec101g="C"} 
else if(mec101sc >=50)
{mec101gp=2.50; mec101g="CD";
} else if( mec101sc >=45) 
{mec101gp=2.25; mec101g="D";}
else if( mec101sc >=40) 
{mec101gp=2.00; mec101g="P";}
else if( mec101sc >=30) 
{mec101gp=1.50; mec101g="F3";}
else if( mec101sc >=20) 
{mec101gp=1.00; mec101g="F2";} 
else if( mec101sc >=10) 
{mec101gp=0.50; mec101g="F1";}
else if( mec101sc >=0) 
{mec101gp=0.00; mec101g="F";}
var mec104gp="";

if(mec104sc >= 75) 
{
mec104gp=4.00; mec104g="A"; }
else if(mec104sc >= 70) {
mec104gp=3.50; mec104g="AB";}
else if(mec104sc >=65)
{mec104gp=3.00; mec104g="B";}
else if(mec104sc >=60)
{mec104gp=3.50; mec104g="BC";}
else if(mec104sc >=55)
{mec104gp=2.27; mec104g="C"} 
else if(mec104sc >=50)
{mec104gp=2.50; mec104g="CD";
} else if( mec104sc >=45) 
{mec104gp=2.25; mec104g="D";}
else if( mec104sc >=40) 
{mec104gp=2.00; mec104g="P";}
else if( mec104sc >=30) 
{mec104gp=1.50; mec104g="F3";}
else if( mec104sc >=20) 
{mec104gp=1.00; mec104g="F2";} 
else if( mec104sc >=10) 
{mec104gp=0.50; mec104g="F1";}
else if( mec104sc >=0) 
{mec104gp=0.00; mec104g="F";}
var mec107gp="";

if(mec107sc >= 75) 
{
mec107gp=4.00; mec107g="A"; }
else if(mec107sc >= 70) {
mec107gp=3.50; mec107g="AB";}
else if(mec107sc >=65)
{mec107gp=3.00; mec107g="B";}
else if(mec107sc >=60)
{mec107gp=3.50; mec107g="BC";}
else if(mec107sc >=55)
{mec107gp=2.27; mec107g="C"} 
else if(mec107sc >=50)
{mec107gp=2.50; mec107g="CD";
} else if( mec107sc >=45) 
{mec107gp=2.25; mec107g="D";}
else if( mec107sc >=40) 
{mec107gp=2.00; mec107g="P";}
else if( mec107sc >=30) 
{mec107gp=1.50; mec107g="F3";}
else if( mec107sc >=20) 
{mec107gp=1.00; mec107g="F2";} 
else if( mec107sc >=10) 
{mec107gp=0.50; mec107g="F1";}
else if( mec107sc >=0) 
{mec107gp=0.00; mec107g="F";}
var eec112gp="";

if(eec112sc >= 75) 
{
eec112gp=4.00; eec112g="A"; }
else if(eec112sc >= 70) {
eec112gp=3.50; eec112g="AB";}
else if(eec112sc >=65)
{eec112gp=3.00; eec112g="B";}
else if(eec112sc >=60)
{eec112gp=3.50; eec112g="BC";}
else if(eec112sc >=55)
{eec112gp=2.27; eec112g="C"} 
else if(eec112sc >=50)
{eec112gp=2.50; eec112g="CD";
} else if( eec112sc >=45) 
{eec112gp=2.25; eec112g="D";}
else if( eec112sc >=40) 
{eec112gp=2.00; eec112g="P";}
else if( eec112sc >=30) 
{eec112gp=1.50; eec112g="F3";}
else if( eec112sc >=20) 
{eec112gp=1.00; eec112g="F2";} 
else if( eec112sc >=10) 
{eec112gp=0.50; eec112g="F1";}
else if( eec112sc >=0) 
{eec112gp=0.00; eec112g="F";}
var com111gp="";

if(com111sc >= 75) 
{
com111gp=4.00; com111g="A"; }
else if(com111sc >= 70) {
com111gp=3.50; com111g="AB";}
else if(com111sc >=65)
{com111gp=3.00; com111g="B";}
else if(com111sc >=60)
{com111gp=3.50; com111g="BC";}
else if(com111sc >=55)
{com111gp=2.27; com111g="C"} 
else if(com111sc >=50)
{com111gp=2.50; com111g="CD";
} else if( com111sc >=45) 
{com111gp=2.25; com111g="D";}
else if( com111sc >=40) 
{com111gp=2.00; com111g="P";}
else if( com111sc >=30) 
{com111gp=1.50; com111g="F3";}
else if( com111sc >=20) 
{com111gp=1.00; com111g="F2";} 
else if( com111sc >=10) 
{com111gp=0.50; com111g="F1";}
else if( com111sc >=0) 
{com111gp=0.00; com111g="F";}
var com112gp="";
if(com112sc >= 75) 
{
com112gp=4.00; com112g="A"; }
else if(com112sc >= 70) {
com112gp=3.50; com112g="AB";}
else if(com112sc >=65)
{com112gp=3.00; com112g="B";}
else if(com112sc >=60)
{com112gp=3.50; com112g="BC";}
else if(com112sc >=55)
{com112gp=2.27; com112g="C"} 
else if(com112sc >=50)
{com112gp=2.50; com112g="CD";
} else if( com112sc >=45) 
{com112gp=2.25; com112g="D";}
else if( com112sc >=40) 
{com112gp=2.00; com112g="P";}
else if( com112sc >=30) 
{com112gp=1.50; com112g="F3";}
else if( com112sc >=20) 
{com112gp=1.00; com112g="F2";} 
else if( com112sc >=10) 
{com112gp=0.50; com112g="F1";}
else if( com112sc >=0) 
{com112gp=0.00; com112g="F";}
var cte112gp=""; 

if(cte112sc >= 75) 
{
cte112gp=4.00; cte112g="A"; }
else if(cte112sc >= 70) {
cte112gp=3.50; cte112g="AB";}
else if(cte112sc >=65)
{cte112gp=3.00; cte112g="B";}
else if(cte112sc >=60)
{cte112gp=3.50; cte112g="BC";}
else if(cte112sc >=55)
{cte112gp=2.27; cte112g="C"} 
else if(cte112sc >=50)
{cte112gp=2.50; cte112g="CD";
} else if( cte112sc >=45) 
{cte112gp=2.25; cte112g="D";}
else if( cte112sc >=40) 
{cte112gp=2.00; cte112g="P";}
else if( cte112sc >=30) 
{cte112gp=1.50; cte112g="F3";}
else if( cte112sc >=20) 
{cte112gp=1.00; cte112g="F2";} 
else if( cte112sc >=10) 
{cte112gp=0.50; cte112g="F1";}
else if( cte112sc >=0) 
{cte112gp=0.00; cte112g="F";}
var totalgp=gns101gp+gns127gp+gns121gp+math112gp+stat112gp+mec101gp+mec107gp+mec104gp+eec112gp+com111gp+com112gp+cte112gp;
var totalcu=gns101cu+gns127cu+gns121cu+math112cu+stat112cu+mec101cu+mec107cu+mec104cu+eec112cu+com111cu+com112cu+cte112cu;
var gp=totalgp*totalcu/totalcu;
document.getElementById("display").innerHTML=gp;
document.getElementById("gns101gf").innerHTML=gns101g;
} 

</script>
