function mygp() {
var gns101sc=document.getElementById("gns101score").value;
var gns127sc=document.getElementById("gns127score").value;
var gns121sc=document.getElementById("gns121score").value;
var math112sc=document.getElementById("math112score").value;
var stat111sc=document.getElementById("stat111score").value;
var mec101sc=document.getElementById("mec101score").value;
var mec104sc=document.getElementById("mec104score").value;
var mec107sc=document.getElementById("mec107score").value;
var eec112sc=document.getElementById("eec112score").value;
var com111sc=document.getElementById("com111score").value;
var com112sc=document.getElementById("com112score").value;
var cte112sc=document.getElementById("cte112score").value;
var gns101cu=2;
var gns127cu=2;
var gns121cu=2;
var math112cu=2;
var stat111cu=2;
var mec101cu=2;
var mec104cu=2;
var mec107cu=2;
var eec112cu=3;
var com111cu=2;
var com112cu=3;
var cte112cu=2;
var gns101gp="";
var gns101g="";

if(gns101sc >= 75) 
{
gns101gp=4.00; gns101g="A"; }
else if(gns101sc >= 70) {
gns101gp=3.50; gns101g="AB";}
else if(gns101sc >= 65)
{gns101gp=3.00; gns101g="B";}
else if(gns101sc >= 60)
{gns101gp=3.50; gns101g="BC";}
else if(gns101sc >=55)
{gns101gp=2.27; gns101g="C"} 
else if(gns101sc >= 50)
{gns101gp=2.50; gns101g="CD";
} else if( gns101sc >= 45) 
{gns101gp=2.25; gns101g="D";}
else if( gns101sc >= 40) 
{gns101gp=2.00; gns101g="P";}
else if( gns101sc >= 30) 
{gns101gp=1.50; gns101g="F3";}
else if( gns101sc >= 20) 
{gns101gp=1.00; gns101g="F2";} 
else if( gns101sc >= 10) 
{gns101gp=0.50; gns101g="F1";}
else if( gns101sc >= 0) 
{gns101gp=0.00; gns101g="F";}

var gp=gns101gp*gns101cu/gns101cu;
document.getElementById("display").innerHTML=gp;
document.getElementById("").innerHTML=gns101g;
 
}